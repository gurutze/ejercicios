	console.log("¡Hola mundo!");
		/*
		
		*/